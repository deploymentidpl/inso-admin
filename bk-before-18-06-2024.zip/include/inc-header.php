<div class="theme-header">
    <a href="#" class="is-flex is-gap-2 is-align-items-center is-justify-content-end">
        <img class="avatar avatar-sm" src="media/images/avatars/1.png" alt="Avatars">
        <span class="fs-7 fw-500">John Doe</span>
    </a>
</div>

