<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $uploadDirectory = 'uploads/';

        // Ensure the upload directory exists
        if (!is_dir($uploadDirectory)) {
            mkdir($uploadDirectory, 0777, true);
        }

        // Generate a unique file name to prevent overwriting existing files
        $fileName = uniqid() . '-' . basename($file['name']);
        $uploadPath = $uploadDirectory . $fileName;

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            echo json_encode(['message' => 'File uploaded successfully!']);
        } else {
            echo json_encode(['message' => 'Upload failed.']);
        }
    } else {
        echo json_encode(['message' => 'No file uploaded.']);
    }
} else {
    echo json_encode(['message' => 'Invalid request method.']);
}
?>